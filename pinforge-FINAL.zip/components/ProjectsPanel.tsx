'use client'

import { useState } from 'react'
import { toast } from '@/components/Toast'
import type { Project, ProjectStatus } from '@/types'
import { PROJECT_STATUS_LABELS, PROJECT_STATUS_COLORS } from '@/types'

interface ProjectsPanelProps {
  projects: Project[]
  activeProjectId: string | null
  onSelect: (id: string) => void
  onCreate: (name: string) => void
  onDuplicate: (id: string) => void
  onDelete: (id: string) => void
  onRename: (id: string, name: string) => void
  onStatusChange: (id: string, status: ProjectStatus) => void
}

export default function ProjectsPanel({
  projects, activeProjectId, onSelect, onCreate, onDuplicate, onDelete, onRename, onStatusChange,
}: ProjectsPanelProps) {
  const [creating, setCreating] = useState(false)
  const [newName, setNewName] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingName, setEditingName] = useState('')

  function handleCreate() {
    const name = newName.trim() || `Project ${projects.length + 1}`
    onCreate(name)
    setNewName('')
    setCreating(false)
    toast(`Project "${name}" created`)
  }

  function handleRename(id: string) {
    if (editingName.trim()) {
      onRename(id, editingName.trim())
      toast('Renamed')
    }
    setEditingId(null)
  }

  function statusBadge(status: ProjectStatus) {
    const c = PROJECT_STATUS_COLORS[status]
    return (
      <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 99, fontWeight: 500, background: c.bg, color: c.text, border: `1px solid ${c.border}`, whiteSpace: 'nowrap' }}>
        {PROJECT_STATUS_LABELS[status]}
      </span>
    )
  }

  function formatDate(iso: string) {
    return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  const statusOptions: ProjectStatus[] = ['draft', 'images_pending', 'ready', 'exported']

  return (
    <div style={{ padding: 24, maxWidth: 860 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>Projects</h1>
          <p style={{ fontSize: 13, color: '#6b7280' }}>
            Work on multiple pin campaigns in parallel — save drafts, come back anytime
          </p>
        </div>
        <button className="btn-pinterest" onClick={() => setCreating(true)}>+ New Project</button>
      </div>

      {/* New project input */}
      {creating && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, padding: 14, background: '#fff9f9', border: '1px solid #fecdd3', borderRadius: 10 }}>
          <input
            className="input-base"
            style={{ flex: 1 }}
            placeholder="Project name (e.g. Summer Collection, Q3 Blog Posts...)"
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') handleCreate(); if (e.key === 'Escape') setCreating(false) }}
            autoFocus
          />
          <button className="btn-pinterest" onClick={handleCreate}>Create</button>
          <button onClick={() => setCreating(false)} style={{ padding: '8px 12px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'white', cursor: 'pointer', fontSize: 13 }}>Cancel</button>
        </div>
      )}

      {/* Tip */}
      <div style={{ padding: '10px 14px', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 8, fontSize: 12, color: '#78350f', marginBottom: 16 }}>
        💡 <strong>Tip:</strong> Create a project per campaign. When images are ready, open that project and upload — everything else is already saved!
      </div>

      {projects.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📁</div>
          <p style={{ fontSize: 14, marginBottom: 16 }}>No projects yet</p>
          <button className="btn-pinterest" onClick={() => setCreating(true)}>Create your first project</button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {projects.map(p => {
            const isActive = p.id === activeProjectId
            const pinCount = p.pins.filter(pin => pin.title).length
            const imageCount = p.pins.filter(pin => pin.imageUrl).length
            const missingImages = pinCount - imageCount

            return (
              <div
                key={p.id}
                style={{
                  border: isActive ? '2px solid #E60023' : '1px solid #e5e7eb',
                  borderRadius: 12,
                  background: isActive ? '#fff9f9' : 'white',
                  overflow: 'hidden',
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                }}
                onClick={() => onSelect(p.id)}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px' }}>
                  {/* Icon */}
                  <div style={{
                    width: 40, height: 40, borderRadius: 10, flexShrink: 0,
                    background: isActive ? '#E60023' : '#f3f4f6',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18,
                  }}>
                    {p.status === 'exported' ? '✅' : p.status === 'ready' ? '🚀' : p.status === 'images_pending' ? '🖼️' : '📝'}
                  </div>

                  {/* Name */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    {editingId === p.id ? (
                      <input
                        className="input-base"
                        style={{ fontSize: 14, fontWeight: 600, padding: '4px 8px' }}
                        value={editingName}
                        onChange={e => setEditingName(e.target.value)}
                        onBlur={() => handleRename(p.id)}
                        onKeyDown={e => { if (e.key === 'Enter') handleRename(p.id); if (e.key === 'Escape') setEditingId(null) }}
                        onClick={e => e.stopPropagation()}
                        autoFocus
                      />
                    ) : (
                      <div style={{ fontSize: 14, fontWeight: 600, color: '#111', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {p.name}
                        {isActive && <span style={{ marginLeft: 8, fontSize: 11, background: '#E60023', color: 'white', padding: '1px 7px', borderRadius: 99, fontWeight: 500 }}>Active</span>}
                      </div>
                    )}
                    <div style={{ display: 'flex', gap: 12, marginTop: 3, fontSize: 12, color: '#6b7280' }}>
                      <span>{p.urls.length} URL{p.urls.length !== 1 ? 's' : ''}</span>
                      <span>{pinCount} pin{pinCount !== 1 ? 's' : ''}</span>
                      {missingImages > 0 && (
                        <span style={{ color: '#d97706' }}>⚠ {missingImages} image{missingImages !== 1 ? 's' : ''} missing</span>
                      )}
                      {imageCount > 0 && missingImages === 0 && pinCount > 0 && (
                        <span style={{ color: '#059669' }}>✓ All images ready</span>
                      )}
                      <span>Updated {formatDate(p.updatedAt)}</span>
                    </div>
                  </div>

                  {/* Status badge + actions */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }} onClick={e => e.stopPropagation()}>
                    {statusBadge(p.status)}
                    <select
                      value={p.status}
                      onChange={e => onStatusChange(p.id, e.target.value as ProjectStatus)}
                      style={{ fontSize: 11, padding: '3px 6px', border: '1px solid #e5e7eb', borderRadius: 6, background: 'white', cursor: 'pointer' }}
                    >
                      {statusOptions.map(s => <option key={s} value={s}>{PROJECT_STATUS_LABELS[s]}</option>)}
                    </select>
                    <button
                      onClick={() => { setEditingId(p.id); setEditingName(p.name) }}
                      style={{ padding: '5px 10px', border: '1px solid #e5e7eb', borderRadius: 6, background: 'white', fontSize: 12, cursor: 'pointer' }}
                      title="Rename"
                    >✏️</button>
                    <button
                      onClick={() => { onDuplicate(p.id); toast(`Duplicated "${p.name}"`) }}
                      style={{ padding: '5px 10px', border: '1px solid #e5e7eb', borderRadius: 6, background: 'white', fontSize: 12, cursor: 'pointer' }}
                      title="Duplicate"
                    >⧉</button>
                    <button
                      onClick={() => { if (confirm(`Delete "${p.name}"?`)) { onDelete(p.id); toast('Project deleted') } }}
                      style={{ padding: '5px 10px', border: '1px solid #fecaca', borderRadius: 6, background: '#fef2f2', color: '#dc2626', fontSize: 12, cursor: 'pointer' }}
                      title="Delete"
                    >✕</button>
                  </div>
                </div>

                {/* Progress bar for images */}
                {pinCount > 0 && (
                  <div style={{ padding: '0 16px 10px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: '#9ca3af', marginBottom: 4 }}>
                      <span>Images uploaded</span>
                      <span>{imageCount}/{pinCount}</span>
                    </div>
                    <div style={{ height: 4, background: '#f3f4f6', borderRadius: 99, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${pinCount > 0 ? (imageCount / pinCount) * 100 : 0}%`, background: imageCount === pinCount ? '#059669' : '#E60023', borderRadius: 99, transition: 'width 0.4s' }} />
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
