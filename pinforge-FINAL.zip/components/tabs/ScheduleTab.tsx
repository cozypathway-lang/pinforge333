'use client'

import { useState } from 'react'
import { toast } from '@/components/Toast'
import type { TimeSlot, ScheduleRow, BoardAccount } from '@/types'

interface ScheduleTabProps {
  accounts: BoardAccount[]
  timeSlots: TimeSlot[]
  scheduleRows: ScheduleRow[]
  pinsCount: number
  onSetTimeSlots: (slots: TimeSlot[]) => void
  onGenerateSchedule: (startDate: string, pinsPerDay: number, intervalMins: number) => ScheduleRow[]
}

const PINS_PER_DAY_OPTIONS = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 20]
const INTERVAL_OPTIONS = [
  { label: '30 minutes', value: 30 },
  { label: '1 hour', value: 60 },
  { label: '2 hours', value: 120 },
  { label: '3 hours', value: 180 },
  { label: '4 hours', value: 240 },
  { label: '6 hours', value: 360 },
]

export default function ScheduleTab({
  accounts, timeSlots, scheduleRows, pinsCount,
  onSetTimeSlots, onGenerateSchedule,
}: ScheduleTabProps) {
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0])
  const [pinsPerDay, setPinsPerDay] = useState(3)
  const [intervalMins, setIntervalMins] = useState(60)
  const [selectedAccount, setSelectedAccount] = useState('')

  function addSlot() {
    onSetTimeSlots([...timeSlots, { from: '09:00', to: '12:00' }])
  }

  function removeSlot(idx: number) {
    if (timeSlots.length === 1) { toast('Keep at least one time window', 'error'); return }
    onSetTimeSlots(timeSlots.filter((_, i) => i !== idx))
  }

  function updateSlot(idx: number, key: 'from' | 'to', value: string) {
    onSetTimeSlots(timeSlots.map((s, i) => i === idx ? { ...s, [key]: value } : s))
  }

  function handleGenerate() {
    if (!startDate) { toast('Please set a start date', 'error'); return }
    if (pinsCount === 0) { toast('Generate some pins first', 'error'); return }
    const rows = onGenerateSchedule(startDate, pinsPerDay, intervalMins)
    toast(`Schedule generated — ${rows.length} pins across ${Math.ceil(rows.length / pinsPerDay)} days`)
  }

  const totalDays = pinsCount > 0 ? Math.ceil(pinsCount / pinsPerDay) : 0

  return (
    <div style={{ padding: 24, maxWidth: 760 }}>
      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>Publishing Schedule</h1>
      <p style={{ fontSize: 13, color: '#6b7280', marginBottom: 24 }}>Set timing and daily limits for automated Pinterest publishing</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Start date */}
        <div>
          <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 6 }}>Start Date</label>
          <input className="input-base" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
        </div>

        {/* Pins per day */}
        <div>
          <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 6 }}>Pins Per Day</label>
          <select
            className="input-base"
            value={pinsPerDay}
            onChange={e => setPinsPerDay(Number(e.target.value))}
          >
            {PINS_PER_DAY_OPTIONS.map(n => (
              <option key={n} value={n}>{n} pin{n > 1 ? 's' : ''} / day</option>
            ))}
          </select>
        </div>

        {/* Interval */}
        <div>
          <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 6 }}>Interval Between Pins</label>
          <select className="input-base" value={intervalMins} onChange={e => setIntervalMins(Number(e.target.value))}>
            {INTERVAL_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>

        {/* Account */}
        <div>
          <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 6 }}>Pinterest Account</label>
          <select className="input-base" value={selectedAccount} onChange={e => setSelectedAccount(e.target.value)}>
            <option value="">— Select account (optional) —</option>
            {accounts.map(a => <option key={a.id} value={String(a.id)}>{a.name}</option>)}
          </select>
        </div>
      </div>

      {/* Summary pill */}
      {pinsCount > 0 && (
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          padding: '8px 14px', background: '#fff0f1', border: '1px solid #fecdd3',
          borderRadius: 8, fontSize: 13, color: '#be123c', marginBottom: 20,
        }}>
          📅 {pinsCount} pins → <strong>{totalDays} days</strong> at {pinsPerDay}/day
        </div>
      )}

      {/* Time windows */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 10, color: '#374151' }}>
          🕐 Publishing Windows
        </div>
        <div style={{ padding: '10px 14px', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 8, fontSize: 12, color: '#1d4ed8', marginBottom: 12 }}>
          Pins will only be scheduled within these daily time windows
        </div>
        {timeSlots.map((slot, idx) => (
          <div key={idx} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
            <input
              className="input-base"
              type="time"
              style={{ flex: 1 }}
              value={slot.from}
              onChange={e => updateSlot(idx, 'from', e.target.value)}
            />
            <span style={{ fontSize: 13, color: '#9ca3af', flexShrink: 0 }}>to</span>
            <input
              className="input-base"
              type="time"
              style={{ flex: 1 }}
              value={slot.to}
              onChange={e => updateSlot(idx, 'to', e.target.value)}
            />
            <button
              onClick={() => removeSlot(idx)}
              style={{ padding: '6px 10px', border: '1px solid #fecaca', borderRadius: 6, background: '#fef2f2', color: '#dc2626', fontSize: 12, cursor: 'pointer', flexShrink: 0 }}
            >✕</button>
          </div>
        ))}
        <button
          onClick={addSlot}
          style={{ padding: '6px 14px', border: '1.5px dashed #d1d5db', borderRadius: 8, background: 'transparent', fontSize: 12, color: '#6b7280', cursor: 'pointer', marginTop: 4 }}
        >+ Add window</button>
      </div>

      <button className="btn-pinterest" onClick={handleGenerate} style={{ marginBottom: 24 }}>
        Generate Schedule
      </button>

      {/* Preview table */}
      {scheduleRows.length > 0 && (
        <div>
          <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 10, color: '#374151' }}>
            Preview — {scheduleRows.length} pins scheduled
          </div>
          <div style={{ border: '1px solid #e5e7eb', borderRadius: 10, overflow: 'hidden', maxHeight: 340, overflowY: 'auto' }}>
            <table className="csv-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Pin Title</th>
                </tr>
              </thead>
              <tbody>
                {scheduleRows.map((row, i) => (
                  <tr key={i}>
                    <td style={{ color: '#9ca3af' }}>{i + 1}</td>
                    <td>{row.date}</td>
                    <td style={{ color: '#E60023', fontWeight: 500 }}>{row.time}</td>
                    <td style={{ maxWidth: 300 }}>{row.pinTitle}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
