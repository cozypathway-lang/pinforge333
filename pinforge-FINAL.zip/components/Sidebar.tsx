'use client'
import type { TabId } from '@/app/page'
import type { Project } from '@/types'
import { PROJECT_STATUS_COLORS, PROJECT_STATUS_LABELS } from '@/types'

interface SidebarProps {
  activeTab: TabId
  onTabChange: (tab: TabId) => void
  stats: { urlCount: number; pinCount: number; accountCount: number; imageCount: number; missingImages: number }
  activeProject: Project | null
  projectCount: number
}

const NAV: { id: TabId; label: string; icon: string }[] = [
  { id: 'projects', label: 'Projects',           icon: '📁' },
  { id: 'urls',     label: 'URLs & Content',     icon: '🔗' },
  { id: 'pins',     label: 'Pin Generator',      icon: '📌' },
  { id: 'accounts', label: 'Accounts & Boards',  icon: '👤' },
  { id: 'schedule', label: 'Schedule',           icon: '🗓' },
  { id: 'export',   label: 'Export CSV',         icon: '📥' },
  { id: 'settings', label: 'Settings',           icon: '⚙️' },
]

export default function Sidebar({ activeTab, onTabChange, stats, activeProject, projectCount }: SidebarProps) {
  return (
    <aside style={{ width: 228, minWidth: 228, background: '#fafafa', borderRight: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column', height: '100vh', position: 'sticky', top: 0 }}>
      <div style={{ padding: '14px 16px', borderBottom: '1px solid #e5e7eb' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: '#E60023', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 0 1 .083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/></svg>
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111', letterSpacing: '-0.02em' }}>PinForge</div>
            <div style={{ fontSize: 11, color: '#9ca3af' }}>Pinterest Generator</div>
          </div>
        </div>
      </div>

      {activeProject && (
        <div style={{ margin: '8px 10px 0', padding: '8px 10px', background: '#fff0f1', border: '1px solid #fecdd3', borderRadius: 8 }}>
          <div style={{ fontSize: 10, color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 2 }}>Active project</div>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#111', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{activeProject.name}</div>
          {(() => { const c = PROJECT_STATUS_COLORS[activeProject.status]; return <span style={{ fontSize: 10, padding: '1px 7px', borderRadius: 99, background: c.bg, color: c.text, border: `1px solid ${c.border}`, fontWeight: 500, display: 'inline-block', marginTop: 3 }}>{PROJECT_STATUS_LABELS[activeProject.status]}</span> })()}
        </div>
      )}

      <nav style={{ flex: 1, padding: '6px 0', marginTop: 4 }}>
        {NAV.map(item => (
          <button key={item.id} onClick={() => onTabChange(item.id)} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '9px 16px', background: activeTab === item.id ? '#fff' : 'transparent', border: 'none', borderLeft: activeTab === item.id ? '2px solid #E60023' : '2px solid transparent', cursor: 'pointer', fontSize: 13, fontWeight: activeTab === item.id ? 500 : 400, color: activeTab === item.id ? '#111' : '#6b7280', textAlign: 'left', transition: 'all 0.12s' }}>
            <span style={{ fontSize: 15 }}>{item.icon}</span>
            <span style={{ flex: 1 }}>{item.label}</span>
            {item.id === 'projects' && projectCount > 0 && <span style={{ fontSize: 11, background: '#f3f4f6', color: '#6b7280', padding: '1px 6px', borderRadius: 99 }}>{projectCount}</span>}
            {item.id === 'pins' && stats.missingImages > 0 && <span style={{ fontSize: 11, background: '#fffbeb', color: '#92400e', padding: '1px 6px', borderRadius: 99 }}>{stats.missingImages}</span>}
          </button>
        ))}
      </nav>

      <div style={{ padding: 12, borderTop: '1px solid #e5e7eb', background: '#f9fafb' }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: '#9ca3af', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>This project</div>
        {[['URLs', stats.urlCount], ['Pins generated', stats.pinCount], ['Images ready', stats.imageCount]].map(([l, v]) => (
          <div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 3 }}>
            <span style={{ color: '#6b7280' }}>{l}</span>
            <span style={{ fontWeight: 600, color: (v as number) > 0 ? '#E60023' : '#9ca3af' }}>{v}</span>
          </div>
        ))}
        {stats.missingImages > 0 && <div style={{ marginTop: 6, padding: '5px 8px', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 6, fontSize: 11, color: '#78350f' }}>⚠ {stats.missingImages} image{stats.missingImages !== 1 ? 's' : ''} missing</div>}
      </div>
    </aside>
  )
}
