'use client'

import { useRef } from 'react'
import type { UrlEntry, PinData } from '@/types'

interface PinCardProps {
  urlEntry: UrlEntry
  pin: PinData
  isGenerating: boolean
  onGenerate: () => void
  onVariation: () => void
  onUpdate: (updates: Partial<PinData>) => void
  onUploadImage: (file: File) => void
}

export default function PinCard({
  urlEntry, pin, isGenerating, onGenerate, onVariation, onUpdate, onUploadImage,
}: PinCardProps) {
  const fileRef = useRef<HTMLInputElement>(null)

  function handleTagKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault()
      const val = e.currentTarget.value.trim().replace(/^#/, '')
      if (val && !pin.tags.includes(val)) {
        onUpdate({ tags: [...pin.tags, val] })
      }
      e.currentTarget.value = ''
    }
    if (e.key === 'Backspace' && !e.currentTarget.value && pin.tags.length > 0) {
      onUpdate({ tags: pin.tags.slice(0, -1) })
    }
  }

  return (
    <div className="card" style={{ marginBottom: 12 }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '10px 14px', background: '#f9fafb', borderBottom: '1px solid #e5e7eb',
      }}>
        <span style={{ fontSize: 12, color: '#6b7280', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
          title={urlEntry.url}>
          🔗 {urlEntry.url}
        </span>
        <div style={{ display: 'flex', gap: 6, flexShrink: 0, marginLeft: 8 }}>
          <button
            onClick={onGenerate}
            disabled={isGenerating}
            className="btn-pinterest"
            style={{ padding: '5px 12px', fontSize: 12 }}
          >
            {isGenerating ? <><span className="pulse-dot" style={{ marginRight: 6 }} />Generating…</> : '✨ Generate'}
          </button>
          {pin.title && (
            <button
              onClick={onVariation}
              disabled={isGenerating}
              style={{ padding: '5px 12px', fontSize: 12, border: '1px solid #e5e7eb', borderRadius: 6, background: 'white', cursor: 'pointer', fontFamily: 'inherit' }}
            >
              🔄 Variation
            </button>
          )}
        </div>
      </div>

      {/* Progress */}
      {isGenerating && (
        <div className="progress-bar" style={{ margin: '0', borderRadius: 0 }}>
          <div className="progress-fill" style={{ width: '70%', animation: 'progress-anim 2s ease infinite' }} />
          <style>{`@keyframes progress-anim{0%{width:10%}60%{width:80%}100%{width:10%}}`}</style>
        </div>
      )}

      {/* Body */}
      <div style={{ padding: 14 }}>
        {/* Image + Title */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
          <div
            onClick={() => fileRef.current?.click()}
            style={{
              width: 72, height: 72, flexShrink: 0,
              border: '1.5px dashed #d1d5db', borderRadius: 10,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', overflow: 'hidden', background: '#f9fafb',
              position: 'relative',
            }}
          >
            {pin.imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={pin.imageUrl} alt="pin" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            ) : (
              <div style={{ textAlign: 'center', fontSize: 10, color: '#9ca3af' }}>📷<br />Upload</div>
            )}
          </div>
          <input type="file" ref={fileRef} accept="image/*" style={{ display: 'none' }}
            onChange={e => e.target.files?.[0] && onUploadImage(e.target.files[0])} />
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>
              Pin Title <span style={{ color: '#9ca3af' }}>({pin.title.length}/100)</span>
            </label>
            <textarea
              className="input-base"
              style={{ minHeight: 56, resize: 'vertical' }}
              maxLength={100}
              placeholder="AI will generate a viral, clickable title..."
              value={pin.title}
              onChange={e => onUpdate({ title: e.target.value })}
            />
          </div>
        </div>

        {/* Description */}
        <div style={{ marginBottom: 12 }}>
          <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>
            SEO Description <span style={{ color: '#9ca3af' }}>({pin.description.length}/500)</span>
          </label>
          <textarea
            className="input-base"
            style={{ minHeight: 72, resize: 'vertical' }}
            maxLength={500}
            placeholder="Keyword-rich, emoji-enhanced description..."
            value={pin.description}
            onChange={e => onUpdate({ description: e.target.value })}
          />
        </div>

        {/* Tags */}
        <div style={{ marginBottom: 12 }}>
          <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>
            Tags <span style={{ color: '#9ca3af' }}>(press Enter to add)</span>
          </label>
          <div
            style={{
              display: 'flex', flexWrap: 'wrap', gap: 4, padding: '6px 8px',
              border: '1px solid #e5e7eb', borderRadius: 8, minHeight: 36, cursor: 'text',
              background: 'white',
            }}
            onClick={e => (e.currentTarget.querySelector('input') as HTMLInputElement)?.focus()}
          >
            {pin.tags.map(tag => (
              <span key={tag} className="tag-chip">
                #{tag}
                <span
                  onClick={() => onUpdate({ tags: pin.tags.filter(t => t !== tag) })}
                  style={{ cursor: 'pointer', color: '#9ca3af', marginLeft: 2 }}
                >×</span>
              </span>
            ))}
            <input
              type="text"
              style={{ border: 'none', outline: 'none', fontSize: 12, minWidth: 80, background: 'transparent', padding: '2px 4px' }}
              placeholder={pin.tags.length === 0 ? 'add tags...' : ''}
              onKeyDown={handleTagKeyDown}
            />
          </div>
        </div>

        {/* Board + Time */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div>
            <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>Board Name</label>
            <input className="input-base" placeholder="Board name" value={pin.board} onChange={e => onUpdate({ board: e.target.value })} />
          </div>
          <div>
            <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>Scheduled Time</label>
            <input className="input-base" type="datetime-local" value={pin.scheduledTime} onChange={e => onUpdate({ scheduledTime: e.target.value })} />
          </div>
        </div>
      </div>
    </div>
  )
}
