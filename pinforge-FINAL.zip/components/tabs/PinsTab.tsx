'use client'

import { toast } from '@/components/Toast'
import PinCard from '@/components/PinCard'
import type { UrlEntry, PinData } from '@/types'

interface PinsTabProps {
  urls: UrlEntry[]
  pins: PinData[]
  generatingIds: Set<number>
  onGenerate: (urlId: number) => void
  onVariation: (urlId: number) => void
  onUpdatePin: (urlId: number, updates: Partial<PinData>) => void
  onUploadImage: (urlId: number, file: File) => void
  onGenerateAll: () => void
}

export default function PinsTab({
  urls, pins, generatingIds,
  onGenerate, onVariation, onUpdatePin, onUploadImage, onGenerateAll,
}: PinsTabProps) {

  function copyAllTitles() {
    const titles = pins.filter(p => p.title).map(p => p.title)
    if (!titles.length) { toast('No titles generated yet', 'error'); return }
    navigator.clipboard.writeText(titles.join('\n'))
      .then(() => toast(`${titles.length} titles copied to clipboard!`))
      .catch(() => toast('Copy failed — try selecting manually', 'error'))
  }

  const generatedCount = pins.filter(p => p.title).length

  return (
    <div style={{ padding: 24, maxWidth: 800 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>Pin Generator</h1>
          <p style={{ fontSize: 13, color: '#6b7280' }}>
            AI-generated viral titles, SEO descriptions & tags
            {generatedCount > 0 && <span style={{ color: '#059669', marginLeft: 6 }}>— {generatedCount}/{urls.length} generated</span>}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
          {generatedCount > 0 && (
            <button
              onClick={copyAllTitles}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '8px 14px', border: '1px solid #e5e7eb',
                borderRadius: 8, background: 'white', fontSize: 13,
                cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500,
              }}
            >
              📋 Copy All Titles
            </button>
          )}
          <button
            className="btn-pinterest"
            onClick={onGenerateAll}
            disabled={urls.length === 0 || generatingIds.size > 0}
          >
            {generatingIds.size > 0 ? `Generating ${generatingIds.size}…` : '✨ Generate All'}
          </button>
        </div>
      </div>

      {urls.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📌</div>
          <p style={{ fontSize: 14, marginBottom: 8 }}>No URLs added yet</p>
          <p style={{ fontSize: 13 }}>Go to <strong>URLs & Content</strong> tab to add your links</p>
        </div>
      ) : (
        urls.map(urlEntry => {
          const pin = pins.find(p => p.urlId === urlEntry.id)
          if (!pin) return null
          return (
            <PinCard
              key={urlEntry.id}
              urlEntry={urlEntry}
              pin={pin}
              isGenerating={generatingIds.has(urlEntry.id)}
              onGenerate={() => onGenerate(urlEntry.id)}
              onVariation={() => onVariation(urlEntry.id)}
              onUpdate={(updates) => onUpdatePin(urlEntry.id, updates)}
              onUploadImage={(file) => onUploadImage(urlEntry.id, file)}
            />
          )
        })
      )}
    </div>
  )
}
