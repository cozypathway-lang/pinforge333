'use client'

import { useState } from 'react'
import { toast } from '@/components/Toast'
import type { AppSettings, AIProvider, StorageProvider } from '@/types'
import { AI_PROVIDERS, STORAGE_PROVIDERS } from '@/types'

interface SettingsTabProps {
  settings: AppSettings
  onSave: (s: AppSettings) => void
}

export default function SettingsTab({ settings, onSave }: SettingsTabProps) {
  const [draft, setDraft] = useState<AppSettings>(JSON.parse(JSON.stringify(settings)))
  const [testing, setTesting] = useState(false)
  const [showKey, setShowKey] = useState(false)

  const aiProvider = AI_PROVIDERS.find(p => p.id === draft.ai.provider)

  function setAI(updates: Partial<typeof draft.ai>) {
    setDraft(d => ({ ...d, ai: { ...d.ai, ...updates } }))
  }
  function setStorage(updates: Partial<typeof draft.storage>) {
    setDraft(d => ({ ...d, storage: { ...d.storage, ...updates } }))
  }
  function handleProviderChange(provider: AIProvider) {
    const p = AI_PROVIDERS.find(x => x.id === provider)!
    setAI({ provider, model: p.models[0] || '', baseUrl: p.baseUrl })
  }

  async function testConnection() {
    setTesting(true)
    try {
      const res = await fetch('/api/generate-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: 'https://example.com/test', aiConfig: draft.ai }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      toast('Connection working! AI responded successfully.')
    } catch (err) {
      toast('Connection failed: ' + (err instanceof Error ? err.message : 'Unknown error'), 'error')
    } finally {
      setTesting(false)
    }
  }

  function handleSave() {
    onSave(draft)
    toast('Settings saved!')
  }

  const inp: React.CSSProperties = { width: '100%', padding: '8px 12px', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 13, fontFamily: 'inherit', color: '#111', background: 'white' }
  const lbl: React.CSSProperties = { fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 4 }
  const card: React.CSSProperties = { background: 'white', border: '1px solid #e5e7eb', borderRadius: 12, padding: 20, marginBottom: 16 }

  const providerGetKeyUrl: Record<string, string> = {
    claude: 'https://console.anthropic.com/settings/keys',
    openai: 'https://platform.openai.com/api-keys',
    grok: 'https://console.x.ai',
  }
  const providerPlaceholder: Record<string, string> = {
    claude: 'sk-ant-api03-...',
    openai: 'sk-...',
    grok: 'xai-...',
    custom: 'your-api-key',
  }

  return (
    <div style={{ padding: 24, maxWidth: 680 }}>
      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>Settings</h1>
      <p style={{ fontSize: 13, color: '#6b7280', marginBottom: 24 }}>
        Configure your AI provider and image storage. Keys are saved in your browser only.
      </p>

      {/* AI PROVIDER */}
      <div style={card}>
        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>AI Provider</div>
        <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>
          Choose which AI generates your pin titles and descriptions
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
          {AI_PROVIDERS.map(p => (
            <button key={p.id} onClick={() => handleProviderChange(p.id)} style={{
              padding: '8px 16px', borderRadius: 99, fontSize: 13, fontWeight: 500,
              cursor: 'pointer', border: '2px solid',
              borderColor: draft.ai.provider === p.id ? '#E60023' : '#e5e7eb',
              background: draft.ai.provider === p.id ? '#fff0f1' : 'white',
              color: draft.ai.provider === p.id ? '#E60023' : '#374151',
            }}>
              {p.label}
            </button>
          ))}
        </div>

        <div style={{ marginBottom: 16 }}>
          <label style={lbl}>
            API Key for {aiProvider?.label}
            {providerGetKeyUrl[draft.ai.provider] && (
              <a
                href={providerGetKeyUrl[draft.ai.provider]}
                target="_blank"
                rel="noreferrer"
                style={{ marginLeft: 8, color: '#E60023', fontSize: 11 }}
              >
                Get key here
              </a>
            )}
          </label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type={showKey ? 'text' : 'password'}
              placeholder={providerPlaceholder[draft.ai.provider] || 'your-api-key'}
              value={draft.ai.apiKey}
              onChange={e => setAI({ apiKey: e.target.value })}
              style={{ ...inp, flex: 1, fontFamily: 'monospace' }}
            />
            <button onClick={() => setShowKey(s => !s)} style={{ padding: '8px 12px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'white', cursor: 'pointer', fontSize: 13 }}>
              {showKey ? 'Hide' : 'Show'}
            </button>
          </div>
          <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>
            Stored in your browser only — sent only to the AI provider you choose
          </div>
        </div>

        <div style={{ marginBottom: 16 }}>
          <label style={lbl}>Model</label>
          {draft.ai.provider === 'custom' ? (
            <input placeholder="e.g. llama-3.1-70b" value={draft.ai.model} onChange={e => setAI({ model: e.target.value })} style={inp} />
          ) : (
            <select value={draft.ai.model} onChange={e => setAI({ model: e.target.value })} style={inp}>
              {(aiProvider?.models || []).map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          )}
        </div>

        {draft.ai.provider === 'custom' && (
          <div style={{ marginBottom: 16 }}>
            <label style={lbl}>API Base URL</label>
            <input placeholder="https://your-api.com/v1" value={draft.ai.baseUrl || ''} onChange={e => setAI({ baseUrl: e.target.value })} style={inp} />
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>Must be OpenAI-compatible</div>
          </div>
        )}

        <button
          onClick={testConnection}
          disabled={!draft.ai.apiKey || testing}
          style={{
            padding: '8px 18px', border: '1px solid #e5e7eb', borderRadius: 8,
            background: 'white', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit',
            opacity: (!draft.ai.apiKey || testing) ? 0.5 : 1,
          }}
        >
          {testing ? 'Testing...' : 'Test Connection'}
        </button>
      </div>

      {/* IMAGE STORAGE */}
      <div style={card}>
        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Image Storage</div>
        <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>
          Where to host images so they get a permanent URL for the Pinterest CSV
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
          {STORAGE_PROVIDERS.map(p => (
            <label key={p.id} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 14px', cursor: 'pointer',
              border: `2px solid ${draft.storage.provider === p.id ? '#E60023' : '#e5e7eb'}`,
              borderRadius: 10,
              background: draft.storage.provider === p.id ? '#fff0f1' : 'white',
            }}>
              <input
                type="radio" name="storage" value={p.id}
                checked={draft.storage.provider === p.id}
                onChange={() => setStorage({ provider: p.id as StorageProvider })}
                style={{ accentColor: '#E60023' }}
              />
              <span style={{ fontSize: 13, fontWeight: 500 }}>{p.label}</span>
            </label>
          ))}
        </div>

        {draft.storage.provider === 'cloudinary' && (
          <div style={{ padding: 14, background: '#f9fafb', borderRadius: 10, border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 12, color: '#374151', marginBottom: 12 }}>
              Free account at{' '}
              <a href="https://cloudinary.com" target="_blank" rel="noreferrer" style={{ color: '#E60023' }}>cloudinary.com</a>
              {' '} — Settings → Upload → Upload presets → Add preset → set to Unsigned
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div>
                <label style={lbl}>Cloud Name</label>
                <input placeholder="your-cloud-name" value={draft.storage.cloudinaryCloud || ''} onChange={e => setStorage({ cloudinaryCloud: e.target.value })} style={inp} />
              </div>
              <div>
                <label style={lbl}>Upload Preset</label>
                <input placeholder="ml_default" value={draft.storage.cloudinaryPreset || ''} onChange={e => setStorage({ cloudinaryPreset: e.target.value })} style={inp} />
              </div>
            </div>
          </div>
        )}

        {draft.storage.provider === 'imgbb' && (
          <div style={{ padding: 14, background: '#f9fafb', borderRadius: 10, border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 12, color: '#374151', marginBottom: 12 }}>
              Free at{' '}
              <a href="https://api.imgbb.com" target="_blank" rel="noreferrer" style={{ color: '#E60023' }}>api.imgbb.com</a>
              {' '} — get a free API key, no credit card needed
            </div>
            <label style={lbl}>ImgBB API Key</label>
            <input placeholder="your-imgbb-key" value={draft.storage.imgbbKey || ''} onChange={e => setStorage({ imgbbKey: e.target.value })} style={{ ...inp, fontFamily: 'monospace' }} />
          </div>
        )}

        {draft.storage.provider === 's3' && (
          <div style={{ padding: 14, background: '#f9fafb', borderRadius: 10, border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 12, color: '#d97706', marginBottom: 12 }}>
              Advanced: requires an AWS account with a public S3 bucket.
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div><label style={lbl}>Bucket Name</label><input placeholder="my-bucket" value={draft.storage.s3Bucket || ''} onChange={e => setStorage({ s3Bucket: e.target.value })} style={inp} /></div>
              <div><label style={lbl}>Region</label><input placeholder="us-east-1" value={draft.storage.s3Region || ''} onChange={e => setStorage({ s3Region: e.target.value })} style={inp} /></div>
              <div><label style={lbl}>Access Key ID</label><input type="password" placeholder="AKIA..." value={draft.storage.s3AccessKey || ''} onChange={e => setStorage({ s3AccessKey: e.target.value })} style={{ ...inp, fontFamily: 'monospace' }} /></div>
              <div><label style={lbl}>Secret Access Key</label><input type="password" placeholder="secret..." value={draft.storage.s3SecretKey || ''} onChange={e => setStorage({ s3SecretKey: e.target.value })} style={{ ...inp, fontFamily: 'monospace' }} /></div>
            </div>
          </div>
        )}
      </div>

      <button onClick={handleSave} style={{ background: '#E60023', color: 'white', border: 'none', borderRadius: 8, padding: '10px 28px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
        Save Settings
      </button>

      <div style={{ marginTop: 16, padding: '10px 14px', background: '#f9fafb', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12, color: '#6b7280' }}>
        All keys are stored only in your browser. They are sent only to your Vercel server to call the AI — never to any third party.
      </div>
    </div>
  )
}
