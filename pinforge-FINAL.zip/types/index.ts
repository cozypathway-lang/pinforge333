// ============================================================
// PinForge v2 — Shared Types
// ============================================================

export interface UrlEntry {
  id: number
  url: string
}

export interface PinData {
  urlId: number
  title: string
  description: string
  tags: string[]
  imageUrl: string
  board: string
  scheduledTime: string
  link: string
}

export interface BoardAccount {
  id: number
  name: string
  boards: string[]
}

export interface TimeSlot {
  from: string
  to: string
}

export interface ScheduleRow {
  date: string
  time: string
  isoDateTime: string
  pinTitle: string
  pinIdx: number
}

export type ProjectStatus = 'draft' | 'images_pending' | 'ready' | 'exported'

export interface Project {
  id: string
  name: string
  status: ProjectStatus
  createdAt: string
  updatedAt: string
  urls: UrlEntry[]
  pins: PinData[]
  accounts: BoardAccount[]
  timeSlots: TimeSlot[]
  scheduleRows: ScheduleRow[]
  notes: string
}

export const PROJECT_STATUS_LABELS: Record<ProjectStatus, string> = {
  draft: 'Draft',
  images_pending: 'Awaiting Images',
  ready: 'Ready to Export',
  exported: 'Exported',
}

export const PROJECT_STATUS_COLORS: Record<ProjectStatus, { bg: string; text: string; border: string }> = {
  draft:          { bg: '#f3f4f6', text: '#374151', border: '#d1d5db' },
  images_pending: { bg: '#fffbeb', text: '#92400e', border: '#fcd34d' },
  ready:          { bg: '#f0fdf4', text: '#166534', border: '#86efac' },
  exported:       { bg: '#eff6ff', text: '#1e40af', border: '#93c5fd' },
}

// ── AI Provider config ─────────────────────────────────────
export type AIProvider = 'claude' | 'openai' | 'grok' | 'custom'

export interface AIConfig {
  provider: AIProvider
  apiKey: string
  model: string
  baseUrl?: string  // for custom/grok
}

// ── Image Storage config ───────────────────────────────────
export type StorageProvider = 'cloudinary' | 'imgbb' | 's3' | 'none'

export interface StorageConfig {
  provider: StorageProvider
  // Cloudinary
  cloudinaryCloud?: string
  cloudinaryPreset?: string
  // ImgBB
  imgbbKey?: string
  // S3
  s3Bucket?: string
  s3Region?: string
  s3AccessKey?: string
  s3SecretKey?: string
}

export interface AppSettings {
  ai: AIConfig
  storage: StorageConfig
}

export const DEFAULT_SETTINGS: AppSettings = {
  ai: {
    provider: 'claude',
    apiKey: '',
    model: 'claude-sonnet-4-20250514',
  },
  storage: {
    provider: 'none',
  },
}

export const AI_PROVIDERS = [
  { id: 'claude' as AIProvider, label: 'Claude (Anthropic)', models: ['claude-sonnet-4-20250514', 'claude-opus-4-20250514', 'claude-haiku-4-5-20251001'], baseUrl: 'https://api.anthropic.com/v1' },
  { id: 'openai' as AIProvider, label: 'ChatGPT (OpenAI)',   models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo'], baseUrl: 'https://api.openai.com/v1' },
  { id: 'grok'   as AIProvider, label: 'Grok (xAI)',         models: ['grok-2-1212', 'grok-beta'], baseUrl: 'https://api.x.ai/v1' },
  { id: 'custom' as AIProvider, label: 'Custom / Other',     models: [], baseUrl: '' },
]

export const STORAGE_PROVIDERS = [
  { id: 'none'        as StorageProvider, label: 'None — local preview only' },
  { id: 'cloudinary'  as StorageProvider, label: 'Cloudinary (recommended, free tier)' },
  { id: 'imgbb'       as StorageProvider, label: 'ImgBB (free, no account needed)' },
  { id: 's3'          as StorageProvider, label: 'Amazon S3 (advanced)' },
]

export const PINTEREST_CSV_HEADERS = [
  'Title', 'Description', 'Link', 'Image URL',
  'Board', 'Keywords', 'Scheduled time (UTC)', 'Status',
] as const
export type PinterestCSVHeader = typeof PINTEREST_CSV_HEADERS[number]
