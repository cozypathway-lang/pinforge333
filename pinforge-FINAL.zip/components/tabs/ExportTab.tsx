'use client'

import { useState, useEffect, useRef } from 'react'
import { toast } from '@/components/Toast'
import { PINTEREST_CSV_HEADERS } from '@/types'

interface ExportTabProps {
  buildCSVData: () => Record<string, string>[]
}

export default function ExportTab({ buildCSVData }: ExportTabProps) {
  const [rows, setRows] = useState<Record<string, string>[]>([])
  const tableRef = useRef<HTMLTableElement>(null)

  useEffect(() => {
    refresh()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function refresh() {
    const data = buildCSVData()
    setRows(data)
    if (data.length === 0) toast('No pins generated yet — go to Pin Generator first', 'error')
    else toast(`${data.length} pins loaded`)
  }

  function updateCell(rowIdx: number, col: string, value: string) {
    setRows(prev => prev.map((r, i) => i === rowIdx ? { ...r, [col]: value } : r))
  }

  function addRow() {
    const empty: Record<string, string> = {}
    PINTEREST_CSV_HEADERS.forEach(h => { empty[h] = '' })
    setRows(prev => [...prev, empty])
  }

  function deleteRow(idx: number) {
    setRows(prev => prev.filter((_, i) => i !== idx))
    toast('Row deleted')
  }

  function downloadCSV() {
    if (!rows.length) { toast('Nothing to export', 'error'); return }

    const headers = PINTEREST_CSV_HEADERS
    const csvRows = [
      headers.join(','),
      ...rows.map(row =>
        headers.map(h => `"${(row[h] || '').replace(/"/g, '""')}"`).join(',')
      ),
    ]
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `pinterest-pins-${new Date().toISOString().split('T')[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast(`CSV downloaded — ${rows.length} pins`)
  }

  function copyCSV() {
    const headers = PINTEREST_CSV_HEADERS
    const csvRows = [
      headers.join(','),
      ...rows.map(row => headers.map(h => `"${(row[h] || '').replace(/"/g, '""')}"`).join(',')),
    ]
    navigator.clipboard.writeText(csvRows.join('\n'))
      .then(() => toast('CSV copied to clipboard'))
      .catch(() => toast('Copy failed', 'error'))
  }

  return (
    <div style={{ padding: 24 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>Export Pinterest CSV</h1>
          <p style={{ fontSize: 13, color: '#6b7280' }}>
            Click any cell to edit • All columns match Pinterest&apos;s official CSV format
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={refresh}
            style={{ padding: '8px 14px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'white', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}
          >🔄 Refresh</button>
          <button
            onClick={copyCSV}
            style={{ padding: '8px 14px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'white', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}
          >📋 Copy CSV</button>
          <button
            className="btn-pinterest"
            onClick={downloadCSV}
            disabled={rows.length === 0}
          >⬇ Download CSV</button>
        </div>
      </div>

      {/* Info + Add row */}
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 14 }}>
        <div style={{ padding: '8px 12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, fontSize: 12, color: '#15803d', flex: 1 }}>
          ✅ Using Pinterest&apos;s official column format: Title, Description, Link, Image URL, Board, Keywords, Scheduled time, Status
        </div>
        <button
          onClick={addRow}
          style={{ padding: '8px 14px', border: '1.5px dashed #d1d5db', borderRadius: 8, background: 'transparent', fontSize: 12, color: '#6b7280', cursor: 'pointer', whiteSpace: 'nowrap' }}
        >+ Add Row</button>
      </div>

      {rows.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📄</div>
          <p style={{ fontSize: 14, marginBottom: 8 }}>No pin data yet</p>
          <p style={{ fontSize: 13 }}>Generate pins in the <strong>Pin Generator</strong> tab, then come back here</p>
          <button className="btn-pinterest" onClick={refresh} style={{ marginTop: 16 }}>Check for pins</button>
        </div>
      ) : (
        <div style={{ border: '1px solid #e5e7eb', borderRadius: 10, overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto', maxHeight: 500, overflowY: 'auto' }}>
            <table className="csv-table" ref={tableRef} style={{ minWidth: 900 }}>
              <thead>
                <tr>
                  <th style={{ width: 36 }}>#</th>
                  {PINTEREST_CSV_HEADERS.map(h => <th key={h}>{h}</th>)}
                  <th style={{ width: 50 }}>Del</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i}>
                    <td style={{ color: '#9ca3af', textAlign: 'center', userSelect: 'none' }}>{i + 1}</td>
                    {PINTEREST_CSV_HEADERS.map(h => (
                      <td
                        key={h}
                        contentEditable
                        suppressContentEditableWarning
                        onBlur={e => updateCell(i, h, e.currentTarget.innerText)}
                        style={{ cursor: 'text' }}
                      >
                        {row[h] || ''}
                      </td>
                    ))}
                    <td style={{ textAlign: 'center' }}>
                      <button
                        onClick={() => deleteRow(i)}
                        style={{ border: 'none', background: 'transparent', color: '#f87171', fontSize: 14, cursor: 'pointer', padding: '2px 6px' }}
                      >✕</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ padding: '10px 14px', borderTop: '1px solid #f3f4f6', background: '#f9fafb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: '#6b7280' }}>{rows.length} pin{rows.length !== 1 ? 's' : ''} ready to export</span>
            <button className="btn-pinterest" onClick={downloadCSV} style={{ padding: '6px 16px', fontSize: 12 }}>
              ⬇ Download CSV
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
