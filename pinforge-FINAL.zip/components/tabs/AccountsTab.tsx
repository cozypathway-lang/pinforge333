'use client'

import { useState } from 'react'
import { toast } from '@/components/Toast'
import type { BoardAccount } from '@/types'

interface AccountsTabProps {
  accounts: BoardAccount[]
  onAddAccount: (name: string) => void
  onRemoveAccount: (id: number) => void
  onAddBoard: (accountId: number, name: string) => void
  onRemoveBoard: (accountId: number, name: string) => void
}

export default function AccountsTab({
  accounts, onAddAccount, onRemoveAccount, onAddBoard, onRemoveBoard,
}: AccountsTabProps) {
  const [accInput, setAccInput] = useState('')
  const [openBoards, setOpenBoards] = useState<Set<number>>(new Set())

  function handleAdd() {
    const name = accInput.trim()
    if (!name) return
    onAddAccount(name)
    setAccInput('')
    toast(`Account "${name}" added`)
  }

  function toggleBoards(id: number) {
    setOpenBoards(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  function handleAddBoard(accId: number) {
    const name = prompt('Enter board name:')
    if (name?.trim()) {
      onAddBoard(accId, name.trim())
      toast(`Board "${name.trim()}" added`)
    }
  }

  function initials(name: string) {
    return name.replace('@', '').substring(0, 2).toUpperCase()
  }

  return (
    <div style={{ padding: 24, maxWidth: 700 }}>
      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>Accounts & Boards</h1>
      <p style={{ fontSize: 13, color: '#6b7280', marginBottom: 20 }}>
        Manage Pinterest accounts and assign boards to pins
      </p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <input
          className="input-base"
          style={{ flex: 1 }}
          placeholder="Account name or @handle"
          value={accInput}
          onChange={e => setAccInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleAdd()}
        />
        <button className="btn-pinterest" onClick={handleAdd}>+ Add Account</button>
      </div>

      {accounts.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>👤</div>
          <p style={{ fontSize: 14 }}>No accounts yet — add your first Pinterest account above</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {accounts.map(acc => (
            <div key={acc.id} className="card">
              {/* Account row */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px' }}>
                <div style={{
                  width: 38, height: 38, borderRadius: '50%',
                  background: '#E60023', color: 'white',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 700, flexShrink: 0,
                }}>
                  {initials(acc.name)}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{acc.name}</div>
                  <div style={{ fontSize: 12, color: '#6b7280' }}>{acc.boards.length} boards</div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button
                    onClick={() => toggleBoards(acc.id)}
                    style={{
                      padding: '5px 12px', border: '1px solid #e5e7eb',
                      borderRadius: 6, background: 'white', fontSize: 12,
                      cursor: 'pointer', fontFamily: 'inherit',
                      color: openBoards.has(acc.id) ? '#E60023' : '#374151',
                    }}
                  >
                    {openBoards.has(acc.id) ? '▲' : '▼'} Boards
                  </button>
                  <button
                    onClick={() => handleAddBoard(acc.id)}
                    style={{ padding: '5px 12px', border: '1px solid #e5e7eb', borderRadius: 6, background: 'white', fontSize: 12, cursor: 'pointer', fontFamily: 'inherit' }}
                  >
                    + Board
                  </button>
                  <button
                    onClick={() => { onRemoveAccount(acc.id); toast('Account removed') }}
                    style={{ padding: '5px 10px', border: '1px solid #fecaca', borderRadius: 6, background: '#fef2f2', color: '#dc2626', fontSize: 12, cursor: 'pointer' }}
                  >✕</button>
                </div>
              </div>

              {/* Boards panel */}
              {openBoards.has(acc.id) && (
                <div style={{ padding: '10px 14px 14px', background: '#f9fafb', borderTop: '1px solid #f3f4f6' }}>
                  <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 8, fontWeight: 500 }}>BOARDS</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {acc.boards.map(board => (
                      <span key={board} style={{
                        display: 'inline-flex', alignItems: 'center', gap: 5,
                        padding: '4px 12px', border: '1px solid #e5e7eb',
                        borderRadius: 99, fontSize: 12, background: 'white', color: '#374151',
                      }}>
                        {board}
                        <span
                          onClick={() => { onRemoveBoard(acc.id, board); toast(`Board "${board}" removed`) }}
                          style={{ cursor: 'pointer', color: '#9ca3af', fontSize: 14, lineHeight: 1 }}
                        >×</span>
                      </span>
                    ))}
                    <button
                      onClick={() => handleAddBoard(acc.id)}
                      style={{
                        padding: '4px 12px', border: '1.5px dashed #d1d5db',
                        borderRadius: 99, fontSize: 12, background: 'transparent',
                        color: '#9ca3af', cursor: 'pointer',
                      }}
                    >+ Add board</button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
