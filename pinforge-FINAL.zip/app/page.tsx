'use client'
import { useState } from 'react'
import { usePinForge } from '@/hooks/usePinForge'
import Sidebar from '@/components/Sidebar'
import { ToastProvider } from '@/components/Toast'
import ProjectsPanel from '@/components/ProjectsPanel'
import UrlsTab from '@/components/tabs/UrlsTab'
import PinsTab from '@/components/tabs/PinsTab'
import AccountsTab from '@/components/tabs/AccountsTab'
import ScheduleTab from '@/components/tabs/ScheduleTab'
import ExportTab from '@/components/tabs/ExportTab'
import SettingsTab from '@/components/tabs/SettingsTab'

export type TabId = 'projects' | 'urls' | 'pins' | 'accounts' | 'schedule' | 'export' | 'settings'

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabId>('settings')
  const pf = usePinForge()

  const handleTabChange = (tab: TabId) => {
    if (tab !== 'projects' && tab !== 'settings' && !pf.activeProject) {
      setActiveTab('projects'); return
    }
    setActiveTab(tab)
  }

  const needsSetup = !pf.settings.ai.apiKey && activeTab !== 'settings'

  return (
    <>
      <ToastProvider />
      <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
        <Sidebar activeTab={activeTab} onTabChange={handleTabChange} stats={pf.stats} activeProject={pf.activeProject} projectCount={pf.projects.length} />
        <main style={{ flex: 1, overflowY: 'auto', background: '#ffffff' }}>

          {/* First-time banner */}
          {needsSetup && (
            <div style={{ background: '#fff9f9', border: '1px solid #fecdd3', borderRadius: 10, margin: 20, padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#be123c' }}>⚙️ Set up your AI key first</div>
                <div style={{ fontSize: 13, color: '#6b7280', marginTop: 2 }}>Add your Claude, ChatGPT, or Grok API key in Settings before generating pins</div>
              </div>
              <button onClick={() => setActiveTab('settings')} style={{ background: '#E60023', color: 'white', border: 'none', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer', flexShrink: 0, marginLeft: 16 }}>
                Go to Settings →
              </button>
            </div>
          )}

          {!pf.activeProject && activeTab !== 'projects' && activeTab !== 'settings' && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '70%', color: '#9ca3af' }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>📁</div>
              <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 8, color: '#374151' }}>No project selected</p>
              <button style={{ background: '#E60023', color: 'white', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }} onClick={() => setActiveTab('projects')}>Open Projects</button>
            </div>
          )}

          {activeTab === 'settings' && <SettingsTab settings={pf.settings} onSave={pf.saveSettings} />}
          {activeTab === 'projects' && <ProjectsPanel projects={pf.projects} activeProjectId={pf.activeProjectId} onSelect={id => { pf.setActiveProjectId(id); setActiveTab('urls') }} onCreate={pf.createProject} onDuplicate={pf.duplicateProject} onDelete={pf.deleteProject} onRename={pf.renameProject} onStatusChange={pf.setProjectStatus} />}
          {activeTab === 'urls' && pf.activeProject && <UrlsTab urls={pf.urls} pins={pf.pins} cloudinaryCloud={pf.settings.storage.cloudinaryCloud || ''} cloudinaryPreset={pf.settings.storage.cloudinaryPreset || ''} onAddUrl={pf.addUrl} onAddBulkUrls={pf.addBulkUrls} onRemoveUrl={pf.removeUrl} onSetCloudinaryCloud={() => {}} onSetCloudinaryPreset={() => {}} />}
          {activeTab === 'pins' && pf.activeProject && <PinsTab urls={pf.urls} pins={pf.pins} generatingIds={pf.generatingIds} onGenerate={id => pf.generatePin(id, false)} onVariation={id => pf.generatePin(id, true)} onUpdatePin={pf.updatePin} onUploadImage={pf.uploadImage} onGenerateAll={pf.generateAllPins} />}
          {activeTab === 'accounts' && pf.activeProject && <AccountsTab accounts={pf.accounts} onAddAccount={pf.addAccount} onRemoveAccount={pf.removeAccount} onAddBoard={pf.addBoard} onRemoveBoard={pf.removeBoard} />}
          {activeTab === 'schedule' && pf.activeProject && <ScheduleTab accounts={pf.accounts} timeSlots={pf.timeSlots} scheduleRows={pf.scheduleRows} pinsCount={pf.stats.pinCount} onSetTimeSlots={pf.setTimeSlots} onGenerateSchedule={pf.generateSchedule} />}
          {activeTab === 'export' && pf.activeProject && <ExportTab buildCSVData={pf.buildCSVData} />}
        </main>
      </div>
    </>
  )
}
