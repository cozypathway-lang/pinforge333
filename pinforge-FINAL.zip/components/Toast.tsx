'use client'

import { useState, useCallback, useEffect } from 'react'

interface Toast {
  id: number
  message: string
  type: 'success' | 'error' | 'info'
}

let toastId = 0
type ToastFn = (msg: string, type?: Toast['type']) => void
let globalToast: ToastFn | null = null

export function toast(msg: string, type: Toast['type'] = 'success') {
  globalToast?.(msg, type)
}

export function ToastProvider() {
  const [toasts, setToasts] = useState<Toast[]>([])

  const addToast: ToastFn = useCallback((message, type = 'success') => {
    const id = ++toastId
    setToasts(prev => [...prev, { id, message, type }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 2800)
  }, [])

  useEffect(() => { globalToast = addToast; return () => { globalToast = null } }, [addToast])

  const bgColor = (type: Toast['type']) =>
    type === 'success' ? '#059669' : type === 'error' ? '#dc2626' : '#374151'

  return (
    <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
      {toasts.map(t => (
        <div
          key={t.id}
          style={{
            background: bgColor(t.type),
            color: 'white',
            padding: '10px 16px',
            borderRadius: 8,
            fontSize: 13,
            fontWeight: 500,
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            animation: 'toast-in 0.2s ease',
            maxWidth: 320,
          }}
        >
          {t.message}
        </div>
      ))}
      <style>{`@keyframes toast-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </div>
  )
}
