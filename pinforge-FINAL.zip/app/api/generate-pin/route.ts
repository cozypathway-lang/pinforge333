import { NextRequest, NextResponse } from 'next/server'

const PROMPT = (url: string, variation: string) => `You are a Pinterest SEO and viral content expert.

Analyze this URL and generate optimized Pinterest pin content:
URL: ${url}
${variation ? `Previously generated title: "${variation}". Generate a DIFFERENT variation.` : ''}

Requirements:
- title: viral, clickable, curiosity-driven, max 100 chars, use power words
- description: SEO-optimized, 300-500 chars, 2-3 hashtags at end, use emojis
- tags: array of 8-10 Pinterest keywords, no # prefix
- board: best Pinterest board name for this content

CRITICAL: Respond ONLY with a valid JSON object. No markdown, no explanation:
{"title":"...","description":"...","tags":["tag1","tag2"],"board":"Board Name"}`

export async function POST(req: NextRequest) {
  try {
    const { url, existingTitle, aiConfig } = await req.json()
    if (!url) return NextResponse.json({ error: 'URL required' }, { status: 400 })

    const { provider, apiKey, model, baseUrl } = aiConfig || {}
    if (!apiKey) return NextResponse.json({ error: 'No API key configured. Go to Settings tab.' }, { status: 400 })

    const prompt = PROMPT(url, existingTitle || '')
    let text = ''

    // ── Claude (Anthropic native API) ──────────────────────
    if (provider === 'claude') {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: model || 'claude-sonnet-4-20250514',
          max_tokens: 1024,
          messages: [{ role: 'user', content: prompt }],
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error?.message || 'Claude API error')
      text = data.content?.[0]?.text || ''
    }

    // ── OpenAI-compatible (OpenAI, Grok, Custom) ───────────
    else {
      const endpoint = (provider === 'openai') ? 'https://api.openai.com/v1/chat/completions'
        : (provider === 'grok') ? 'https://api.x.ai/v1/chat/completions'
        : (baseUrl?.endsWith('/chat/completions') ? baseUrl : `${baseUrl}/chat/completions`)

      const defaultModel = provider === 'openai' ? 'gpt-4o-mini'
        : provider === 'grok' ? 'grok-2-1212'
        : model || 'gpt-4o-mini'

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
        body: JSON.stringify({
          model: model || defaultModel,
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 1024,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error?.message || 'AI API error')
      text = data.choices?.[0]?.message?.content || ''
    }

    const clean = text.replace(/```json|```/gi, '').trim()
    let parsed: Record<string, unknown>
    try { parsed = JSON.parse(clean) }
    catch { return NextResponse.json({ error: 'AI returned invalid JSON', raw: clean }, { status: 500 }) }

    return NextResponse.json({
      title: parsed.title || '',
      description: parsed.description || '',
      tags: Array.isArray(parsed.tags) ? parsed.tags : [],
      board: parsed.board || '',
    })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
