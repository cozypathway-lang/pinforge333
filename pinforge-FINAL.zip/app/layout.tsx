import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'PinForge — Pinterest Pin & CSV Generator',
  description: 'AI-powered Pinterest pin generator. Create viral titles, SEO descriptions, and export Pinterest-ready CSV files.',
  keywords: ['pinterest', 'pin generator', 'csv export', 'pinterest marketing', 'social media'],
  openGraph: {
    title: 'PinForge — Pinterest Pin & CSV Generator',
    description: 'Generate viral Pinterest pins with AI. Export Pinterest-ready CSV files.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
