'use client'
import { useState } from 'react'
import { toast } from '@/components/Toast'
import type { UrlEntry, PinData } from '@/types'

interface UrlsTabProps {
  urls: UrlEntry[]
  pins: PinData[]
  cloudinaryCloud: string
  cloudinaryPreset: string
  onAddUrl: (url: string) => boolean
  onAddBulkUrls: (text: string) => number
  onRemoveUrl: (id: number) => void
  onSetCloudinaryCloud: (v: string) => void
  onSetCloudinaryPreset: (v: string) => void
}

export default function UrlsTab({ urls, pins, onAddUrl, onAddBulkUrls, onRemoveUrl }: UrlsTabProps) {
  const [urlInput, setUrlInput] = useState('')
  const [bulkInput, setBulkInput] = useState('')

  function handleAdd() {
    if (!urlInput.trim()) return
    const ok = onAddUrl(urlInput)
    if (ok) { setUrlInput(''); toast('URL added!') }
    else toast('Invalid or duplicate URL', 'error')
  }

  function handleBulk() {
    const count = onAddBulkUrls(bulkInput)
    if (count > 0) { setBulkInput(''); toast(`${count} URLs added!`) }
    else toast('No valid URLs found — make sure they start with http', 'error')
  }

  return (
    <div style={{ padding: 24, maxWidth: 760 }}>
      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4, letterSpacing: '-0.03em' }}>URLs & Landing Pages</h1>
      <p style={{ fontSize: 13, color: '#6b7280', marginBottom: 20 }}>Add your destination URLs — AI will generate a full pin for each one</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <input className="input-base" style={{ flex: 1 }} type="url" placeholder="https://yoursite.com/blog/post" value={urlInput} onChange={e => setUrlInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAdd()} />
        <button className="btn-pinterest" onClick={handleAdd}>+ Add URL</button>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <textarea className="input-base" style={{ flex: 1, minHeight: 80, resize: 'vertical' }} placeholder="Paste multiple URLs here, one per line..." value={bulkInput} onChange={e => setBulkInput(e.target.value)} />
        <button onClick={handleBulk} style={{ alignSelf: 'flex-end', padding: '8px 14px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'white', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>Add All</button>
      </div>

      {urls.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '50px 0', color: '#9ca3af' }}>
          <div style={{ fontSize: 36, marginBottom: 10 }}>🔗</div>
          <p style={{ fontSize: 14 }}>No URLs yet — add your first link above</p>
        </div>
      ) : (
        <div style={{ border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
          {urls.map((u, i) => {
            const pin = pins.find(p => p.urlId === u.id)
            return (
              <div key={u.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', borderBottom: i < urls.length - 1 ? '1px solid #f3f4f6' : 'none' }}>
                <span style={{ fontSize: 12, color: '#9ca3af', width: 22, flexShrink: 0 }}>{i + 1}</span>
                <span style={{ flex: 1, fontSize: 12, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={u.url}>{u.url}</span>
                {pin?.title && <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 99, fontWeight: 500, background: '#d1fae5', color: '#065f46', flexShrink: 0 }}>✓ Done</span>}
                {pin?.imageUrl && <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 99, fontWeight: 500, background: '#eff6ff', color: '#1e40af', flexShrink: 0 }}>🖼 Image</span>}
                <button onClick={() => { onRemoveUrl(u.id); toast('URL removed') }} style={{ padding: '3px 8px', border: '1px solid #fecaca', borderRadius: 6, background: '#fef2f2', color: '#dc2626', fontSize: 12, cursor: 'pointer' }}>✕</button>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
