'use client'

import { useState, useCallback } from 'react'
import type { UrlEntry, PinData, BoardAccount, TimeSlot, ScheduleRow, Project, ProjectStatus, AppSettings } from '@/types'
import { DEFAULT_SETTINGS } from '@/types'

const PROJECTS_KEY = 'pinforge_projects_v2'
const SETTINGS_KEY = 'pinforge_settings_v2'

function load<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : fallback } catch { return fallback }
}
function save(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch {}
}

function blankProject(name: string): Project {
  return {
    id: Date.now().toString(), name, status: 'draft',
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    urls: [], pins: [], accounts: [],
    timeSlots: [{ from: '08:00', to: '11:00' }, { from: '17:00', to: '20:00' }],
    scheduleRows: [], notes: '',
  }
}

export function usePinForge() {
  const [projects, setProjects] = useState<Project[]>(() => load(PROJECTS_KEY, []))
  const [activeProjectId, setActiveProjectId] = useState<string | null>(() => {
    const ps = load<Project[]>(PROJECTS_KEY, [])
    return ps[0]?.id ?? null
  })
  const [settings, setSettingsState] = useState<AppSettings>(() => {
    const saved = load<AppSettings>(SETTINGS_KEY, DEFAULT_SETTINGS)
    // merge to pick up any new default keys
    return { ...DEFAULT_SETTINGS, ...saved, ai: { ...DEFAULT_SETTINGS.ai, ...saved.ai }, storage: { ...DEFAULT_SETTINGS.storage, ...saved.storage } }
  })
  const [generatingIds, setGeneratingIds] = useState<Set<number>>(new Set())

  const activeProject = projects.find(p => p.id === activeProjectId) ?? null

  // ── Settings ─────────────────────────────────────────────
  const saveSettings = useCallback((next: AppSettings) => {
    setSettingsState(next)
    save(SETTINGS_KEY, next)
  }, [])

  // ── Projects ─────────────────────────────────────────────
  const persistProjects = useCallback((next: Project[]) => {
    setProjects(next); save(PROJECTS_KEY, next)
  }, [])

  const updateProject = useCallback((id: string, updater: (p: Project) => Project) => {
    setProjects(prev => {
      const next = prev.map(p => p.id === id ? { ...updater(p), updatedAt: new Date().toISOString() } : p)
      save(PROJECTS_KEY, next); return next
    })
  }, [])

  const patchActive = useCallback((updater: (p: Project) => Partial<Project>) => {
    if (!activeProjectId) return
    updateProject(activeProjectId, p => ({ ...p, ...updater(p) }))
  }, [activeProjectId, updateProject])

  const createProject = useCallback((name: string) => {
    const p = blankProject(name)
    setProjects(prev => { const next = [...prev, p]; save(PROJECTS_KEY, next); return next })
    setActiveProjectId(p.id)
    return p.id
  }, [])

  const duplicateProject = useCallback((id: string) => {
    const src = projects.find(p => p.id === id); if (!src) return
    const copy: Project = { ...JSON.parse(JSON.stringify(src)), id: Date.now().toString(), name: src.name + ' (copy)', status: 'draft', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
    setProjects(prev => { const next = [...prev, copy]; save(PROJECTS_KEY, next); return next })
    setActiveProjectId(copy.id)
  }, [projects])

  const deleteProject = useCallback((id: string) => {
    setProjects(prev => {
      const next = prev.filter(p => p.id !== id); save(PROJECTS_KEY, next)
      if (activeProjectId === id) setActiveProjectId(next[0]?.id ?? null)
      return next
    })
  }, [activeProjectId])

  const renameProject = useCallback((id: string, name: string) => updateProject(id, p => ({ ...p, name })), [updateProject])
  const setProjectStatus = useCallback((id: string, status: ProjectStatus) => updateProject(id, p => ({ ...p, status })), [updateProject])

  // ── URLs ──────────────────────────────────────────────────
  const addUrl = useCallback((rawUrl: string) => {
    const url = rawUrl.trim()
    if (!url.startsWith('http')) return false
    if (activeProject?.urls.find(u => u.url === url)) return false
    const entry: UrlEntry = { id: Date.now() + Math.random(), url }
    patchActive(p => ({ urls: [...p.urls, entry], pins: [...p.pins, { urlId: entry.id, title: '', description: '', tags: [], imageUrl: '', board: '', scheduledTime: '', link: url }] }))
    return true
  }, [activeProject, patchActive])

  const addBulkUrls = useCallback((text: string) => {
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.startsWith('http'))
    let added = 0
    lines.forEach(url => {
      if (!activeProject?.urls.find(u => u.url === url)) {
        const entry: UrlEntry = { id: Date.now() + Math.random(), url }
        patchActive(p => ({ urls: [...p.urls, entry], pins: [...p.pins, { urlId: entry.id, title: '', description: '', tags: [], imageUrl: '', board: '', scheduledTime: '', link: url }] }))
        added++
      }
    })
    return added
  }, [activeProject, patchActive])

  const removeUrl = useCallback((id: number) => {
    patchActive(p => ({ urls: p.urls.filter(u => u.id !== id), pins: p.pins.filter(pin => pin.urlId !== id) }))
  }, [patchActive])

  // ── Pins ──────────────────────────────────────────────────
  const updatePin = useCallback((urlId: number, updates: Partial<PinData>) => {
    patchActive(p => ({ pins: p.pins.map(pin => pin.urlId === urlId ? { ...pin, ...updates } : pin) }))
  }, [patchActive])

  const generatePin = useCallback(async (urlId: number, isVariation = false) => {
    const urlEntry = activeProject?.urls.find(u => u.id === urlId); if (!urlEntry) return
    const existingPin = activeProject?.pins.find(p => p.urlId === urlId)
    setGeneratingIds(prev => new Set(prev).add(urlId))
    try {
      const res = await fetch('/api/generate-pin', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlEntry.url, existingTitle: isVariation ? existingPin?.title : undefined, aiConfig: settings.ai }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      updatePin(urlId, { title: data.title, description: data.description, tags: data.tags, board: existingPin?.board || data.board })
    } catch (err) {
      const kw = extractKeyword(urlEntry.url)
      updatePin(urlId, { title: localTitle(kw, isVariation ? existingPin?.title || '' : ''), description: localDesc(kw), tags: localTags(kw), board: existingPin?.board || kw + ' Ideas' })
      console.error('generatePin:', err)
    } finally {
      setGeneratingIds(prev => { const s = new Set(prev); s.delete(urlId); return s })
    }
  }, [activeProject, settings.ai, updatePin])

  const generateAllPins = useCallback(async () => {
    if (!activeProject) return
    for (const u of activeProject.urls) await generatePin(u.id)
  }, [activeProject, generatePin])

  // ── Images ────────────────────────────────────────────────
  const uploadImage = useCallback(async (urlId: number, file: File) => {
    const localUrl = URL.createObjectURL(file)
    updatePin(urlId, { imageUrl: localUrl })
    if (settings.storage.provider === 'none') return localUrl
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('storageConfig', JSON.stringify(settings.storage))
      const res = await fetch('/api/upload-image', { method: 'POST', body: fd })
      const data = await res.json()
      if (data.url) { updatePin(urlId, { imageUrl: data.url }); return data.url }
    } catch (err) { console.error('uploadImage:', err) }
    return localUrl
  }, [settings.storage, updatePin])

  // ── Accounts ──────────────────────────────────────────────
  const addAccount = useCallback((name: string) => {
    const acc: BoardAccount = { id: Date.now(), name: name.trim(), boards: ['Home Decor', 'Fashion', 'Food & Recipes', 'Travel', 'DIY & Crafts'] }
    patchActive(p => ({ accounts: [...p.accounts, acc] }))
  }, [patchActive])
  const removeAccount = useCallback((id: number) => patchActive(p => ({ accounts: p.accounts.filter(a => a.id !== id) })), [patchActive])
  const addBoard = useCallback((accountId: number, boardName: string) => {
    patchActive(p => ({ accounts: p.accounts.map(a => a.id === accountId && !a.boards.includes(boardName) ? { ...a, boards: [...a.boards, boardName] } : a) }))
  }, [patchActive])
  const removeBoard = useCallback((accountId: number, boardName: string) => {
    patchActive(p => ({ accounts: p.accounts.map(a => a.id === accountId ? { ...a, boards: a.boards.filter(b => b !== boardName) } : a) }))
  }, [patchActive])

  // ── Schedule ──────────────────────────────────────────────
  const generateSchedule = useCallback((startDate: string, pinsPerDay: number, intervalMins: number) => {
    if (!activeProject) return []
    const withContent = activeProject.pins.filter(p => p.title)
    if (!withContent.length || !startDate) return []
    const rows: ScheduleRow[] = []; let pinIdx = 0; let day = 0
    const slots = activeProject.timeSlots
    while (pinIdx < withContent.length && day < 90) {
      const date = new Date(startDate + 'T00:00:00'); date.setDate(date.getDate() + day)
      for (let i = 0; i < pinsPerDay && pinIdx < withContent.length; i++) {
        const slot = slots[i % slots.length]; const [h, m] = slot.from.split(':').map(Number)
        const t = new Date(date); t.setHours(h, m + Math.floor((i / slots.length) * intervalMins), 0, 0)
        rows.push({ date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }), time: t.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }), isoDateTime: t.toISOString(), pinTitle: withContent[pinIdx].title, pinIdx })
        pinIdx++
      }
      day++
    }
    patchActive(() => ({ scheduleRows: rows })); return rows
  }, [activeProject, patchActive])

  const setTimeSlots = useCallback((slots: TimeSlot[]) => patchActive(() => ({ timeSlots: slots })), [patchActive])

  // ── CSV ───────────────────────────────────────────────────
  const buildCSVData = useCallback(() => {
    if (!activeProject) return []
    return activeProject.pins.filter(p => p.title).map((pin, idx) => ({
      'Title': pin.title, 'Description': pin.description, 'Link': pin.link,
      'Image URL': pin.imageUrl, 'Board': pin.board,
      'Keywords': (pin.tags || []).map(t => '#' + t).join(' '),
      'Scheduled time (UTC)': activeProject.scheduleRows[idx]?.isoDateTime || pin.scheduledTime || '',
      'Status': 'queued',
    }))
  }, [activeProject])

  const stats = {
    urlCount: activeProject?.urls.length ?? 0,
    pinCount: activeProject?.pins.filter(p => p.title).length ?? 0,
    accountCount: activeProject?.accounts.length ?? 0,
    imageCount: activeProject?.pins.filter(p => p.imageUrl).length ?? 0,
    missingImages: activeProject?.pins.filter(p => p.title && !p.imageUrl).length ?? 0,
  }

  return {
    projects, activeProject, activeProjectId, setActiveProjectId,
    createProject, duplicateProject, deleteProject, renameProject, setProjectStatus,
    settings, saveSettings,
    generatingIds,
    urls: activeProject?.urls ?? [], pins: activeProject?.pins ?? [],
    accounts: activeProject?.accounts ?? [], timeSlots: activeProject?.timeSlots ?? [],
    scheduleRows: activeProject?.scheduleRows ?? [],
    stats,
    addUrl, addBulkUrls, removeUrl,
    updatePin, generatePin, generateAllPins, uploadImage,
    addAccount, removeAccount, addBoard, removeBoard,
    setTimeSlots, generateSchedule, buildCSVData,
  }
}

function extractKeyword(url: string) {
  try { const p = new URL(url).pathname.split('/').filter(Boolean); return (p[p.length-1]||'content').replace(/[-_]/g,' ').replace(/\.\w+$/,'').replace(/\b\w/g,c=>c.toUpperCase()) } catch { return 'Your Topic' }
}
const TITLES = [(k:string)=>`${k} Ideas That'll Change Your Life`, (k:string)=>`The Ultimate ${k} Guide`, (k:string)=>`Why Everyone's Obsessed With ${k}`, (k:string)=>`${k}: What Nobody Tells You`, (k:string)=>`10 ${k} Tricks That Actually Work`, (k:string)=>`How to Master ${k} in 30 Days`, (k:string)=>`Stop Doing ${k} Wrong — Do This Instead`]
function localTitle(kw: string, existing: string) { return (TITLES.find(t=>t(kw)!==existing)||TITLES[0])(kw) }
function localDesc(kw: string) { return `✨ Discover the best ${kw} tips that actually work! Save this pin for later. #${kw.replace(/\s/g,'')} #${kw.split(' ')[0]}Tips #Pinterest` }
function localTags(kw: string) { return [kw.toLowerCase(),kw.toLowerCase().replace(/\s/g,''),kw.split(' ')[0].toLowerCase()+'tips','pinterest','viral','2025'] }
